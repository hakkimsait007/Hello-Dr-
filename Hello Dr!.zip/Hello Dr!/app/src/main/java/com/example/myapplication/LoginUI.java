package com.example.myapplication;

import android.content.Intent;
import android.os.Bundle;
import android.support.v7.app.AppCompatActivity;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.TextView;
import android.widget.Toast;

public class LoginUI extends AppCompatActivity {
    private EditText userEdittext;
    private EditText passEdittext;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_login_ui);

        userEdittext = findViewById(R.id.email_editText);
        passEdittext = findViewById(R.id.pass_editText);
        final Button buttonLogin = findViewById(R.id.login_button);

        buttonLogin.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                if(userEdittext.getText().length() > 0 && passEdittext.getText().length() > 0){
                    String toastMessage = "Username : " + userEdittext.getText().toString() + ",\n Password: " + passEdittext.getText().toString() + "\nRedirecting...";
                    Toast.makeText(getApplicationContext(), toastMessage, Toast.LENGTH_SHORT).show();

                   // Intent intent = new Intent(LoginUI.this,SplashActivity.class);
                    //startActivity(intent);
                }
                else{
                    String toastMessage = "Incorrect User Credentials!!";
                    Toast.makeText(getApplicationContext(),toastMessage, Toast.LENGTH_SHORT).show();
                }
            }
        });


        TextView signUp_btn = findViewById(R.id.signup_textView);
        signUp_btn.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                startActivity(new Intent(LoginUI.this,RegisterUI.class));
            }
        });

    }
}
